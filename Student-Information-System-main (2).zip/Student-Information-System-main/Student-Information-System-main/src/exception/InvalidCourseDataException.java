package exception;

public class InvalidCourseDataException extends Exception {
    public InvalidCourseDataException(String message) {
        super(message);
    }
}