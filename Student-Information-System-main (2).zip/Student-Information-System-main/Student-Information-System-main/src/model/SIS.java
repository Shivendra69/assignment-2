package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SIS {
    // Data structures to store information about students, courses, teachers, enrollments, and payments
    private List<Student> students = new ArrayList<>();
    private List<Course> courses = new ArrayList<>();
    private List<Teacher> teachers = new ArrayList<>();
    private List<Enrollment> enrollments = new ArrayList<>();
    private List<Payment> payments = new ArrayList<>();

    // Constructor: Initializes empty lists for the SIS system
    public SIS() {
        // You could initialize with sample data here if needed
    }

    // Method 1: Enroll a student in a course
    public void EnrollStudentInCourse(Student student, Course course) throws DuplicateEnrollmentException, InvalidEnrollmentDataException {
        // Check if the student is already enrolled in the course
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getStudent().getStudentId() == student.getStudentId() &&
                    enrollment.getCourse().getCourseId() == course.getCourseId()) {
                throw new DuplicateEnrollmentException("Student " + student.getFirstName() + " is already enrolled in " + course.getCourseName());
            }
        }

        // Validate enrollment data (e.g., student or course data might be null)
        if (student == null || course == null) {
            throw new InvalidEnrollmentDataException("Invalid data: Student or Course cannot be null.");
        }

        // Create a new enrollment and add it to the list
        Enrollment newEnrollment = new Enrollment(student, course, new Date());
        enrollments.add(newEnrollment);
        student.EnrollInCourse(course); // Enroll the student in the course
        course.GetEnrollments().add(newEnrollment); // Add this enrollment to the course's enrollments
        System.out.println(student.getFirstName() + " has been successfully enrolled in " + course.getCourseName());
    }

    // Method 2: Assign a teacher to a course
    public void AssignTeacherToCourse(Teacher teacher, Course course) throws TeacherNotFoundException {
        if (teacher == null) {
            throw new TeacherNotFoundException("Teacher not found.");
        }

        course.AssignTeacher(teacher); // Assign teacher to the course
        teacher.getAssignedCourses().add(course); // Add the course to the teacher's assigned courses
        System.out.println("Teacher " + teacher.getFirstName() + " has been assigned to course " + course.getCourseName());
    }

    // Method 3: Record a payment made by the student
    public void RecordPayment(Student student, double amount, Date paymentDate) throws PaymentValidationException {
        if (amount <= 0) {
            throw new PaymentValidationException("Invalid payment amount: Amount must be greater than zero.");
        }

        // Create a new payment and add it to the list of payments
        Payment payment = new Payment(payments.size() + 1, student.getStudentId(), amount, paymentDate);
        payments.add(payment);
        student.MakePayment(amount, paymentDate); // Record the payment for the student
        System.out.println("Payment of " + amount + " has been recorded for student " + student.getFirstName());
    }

    // Method 4: Generate an enrollment report for a specific course
    public void GenerateEnrollmentReport(Course course) {
        System.out.println("Enrollment Report for course: " + course.getCourseName());

        // Flag to check if there are any enrollments in the course
        boolean hasEnrollments = false;

        for (Enrollment enrollment : enrollments) {
            if (enrollment.getCourse().getCourseId() == course.getCourseId()) {
                hasEnrollments = true;
                System.out.println("Student: " + enrollment.getStudent().getFirstName() + " " + enrollment.getStudent().getLastName() +
                        ", Enrolled on: " + enrollment.getEnrollmentDate());
            }
        }

        // If no enrollments are found for the course
        if (!hasEnrollments) {
            System.out.println("No students are enrolled in this course.");
        }
    }

    // Method 5: Generate a payment report for a specific student
    public void GeneratePaymentReport(Student student) {
        System.out.println("Payment Report for student: " + student.getFirstName() + " " + student.getLastName());

        // Flag to check if there are any payments for the student
        boolean hasPayments = false;

        for (Payment payment : payments) {
            if (payment.getStudentId() == student.getStudentId()) {
                hasPayments = true;
                System.out.println("Payment Amount: " + payment.getPaymentAmount() + " on " + payment.getPaymentDate());
            }
        }

        // If no payments are found for the student
        if (!hasPayments) {
            System.out.println("No payments found for this student.");
        }
    }

    // Method 6: Calculate course statistics (enrollments and total payments)
    public void CalculateCourseStatistics(Course course) {
        int enrollmentCount = 0;
        double totalPayments = 0;

        // Count enrollments for the course
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getCourse().getCourseId() == course.getCourseId()) {
                enrollmentCount++;
            }
        }

        // Sum payments for the course (through students enrolled in the course)
        for (Payment payment : payments) {
            for (Enrollment enrollment : enrollments) {
                if (enrollment.getStudent().getStudentId() == payment.getStudentId() &&
                        enrollment.getCourse().getCourseId() == course.getCourseId()) {
                    totalPayments += payment.getPaymentAmount();
                }
            }
        }

        // Print course statistics
        System.out.println("Course Statistics for: " + course.getCourseName());
        System.out.println("Total Enrollments: " + enrollmentCount);
        System.out.println("Total Payments: " + totalPayments);
    }

    // Method 7: Add Enrollment (Student, Course, Enrollment Date)
    public void AddEnrollment(Student student, Course course, Date enrollmentDate) throws DuplicateEnrollmentException, InvalidEnrollmentDataException {
        // Check for duplicate enrollment
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getStudent().getStudentId() == student.getStudentId() &&
                    enrollment.getCourse().getCourseId() == course.getCourseId()) {
                throw new DuplicateEnrollmentException("Student " + student.getFirstName() + " is already enrolled in this course.");
            }
        }

        // Create the new enrollment
        Enrollment newEnrollment = new Enrollment(student, course, enrollmentDate);
        enrollments.add(newEnrollment);
        student.EnrollInCourse(course);
        course.GetEnrollments().add(newEnrollment);
        System.out.println("Enrollment added for student " + student.getFirstName() + " in course " + course.getCourseName());
    }

    // Method 8: Assign Course to Teacher (Course, Teacher)
    public void AssignCourseToTeacher(Course course, Teacher teacher) throws TeacherNotFoundException {
        if (teacher == null) {
            throw new TeacherNotFoundException("Teacher not found.");
        }

        course.AssignTeacher(teacher);
        teacher.getAssignedCourses().add(course);
        System.out.println("Course " + course.getCourseName() + " has been assigned to teacher " + teacher.getFirstName());
    }

    // Method 9: Add Payment (Student, Amount, Payment Date)
    public void AddPayment(Student student, double amount, Date paymentDate) throws PaymentValidationException {
        if (amount <= 0) {
            throw new PaymentValidationException("Payment amount must be greater than zero.");
        }

        Payment payment = new Payment(payments.size() + 1, student.getStudentId(), amount, paymentDate);
        payments.add(payment);
        student.MakePayment(amount, paymentDate);
        System.out.println("Payment of " + amount + " has been recorded for student " + student.getFirstName());
    }

    // Method 10: Get Enrollments for Student (Student)
    public List<Enrollment> GetEnrollmentsForStudent(Student student) {
        List<Enrollment> studentEnrollments = new ArrayList<>();

        for (Enrollment enrollment : enrollments) {
            if (enrollment.getStudent().getStudentId() == student.getStudentId()) {
                studentEnrollments.add(enrollment);
            }
        }
        return studentEnrollments;
    }

    // Method 11: Get Courses for Teacher (Teacher)
    public List<Course> GetCoursesForTeacher(Teacher teacher) {
        return teacher.getAssignedCourses();
    }

    // Getters for the lists (if needed)
    public List<Student> getStudents() {
        return students;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public List<Enrollment> getEnrollments() {
        return enrollments;
    }

    public List<Payment> getPayments() {
        return payments;
    }
}
