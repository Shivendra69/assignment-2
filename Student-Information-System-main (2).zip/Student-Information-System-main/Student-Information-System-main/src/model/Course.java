package model;

import java.util.ArrayList;
import java.util.List;

// Custom Exception Definitions
class CourseNotFoundException extends Exception {
    public CourseNotFoundException(String message) {
        super(message);
    }
}

public class Course {
    private int courseId;               // Course ID
    private String courseName;          // Course Name
    private String courseCode;          // Course Code
    private String instructorName;
    private Teacher assignedTeacher;    // Assigned teacher for this course

    // List to store enrollments in this course
    private List<Enrollment> enrollments = new ArrayList<>();

    // Constructor to initialize Course object with given attributes
    public Course(int courseId, String courseName) throws InvalidCourseDataException {
        if (courseId <= 0 || courseName == null || courseName.isEmpty() || courseCode == null || courseCode.isEmpty()) {
            throw new InvalidCourseDataException("Invalid data provided for the course.");
        }

        this.courseId = courseId;
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.instructorName = instructorName;
    }

    // Getter and Setter methods for Course attributes
    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    // Method to assign a teacher to the course
    public void AssignTeacher(Teacher teacher) throws TeacherNotFoundException {
        if (teacher == null) {
            throw new TeacherNotFoundException("Teacher not found for this course.");
        }
        this.assignedTeacher = teacher;  // Assign the teacher to the course
        System.out.println(teacher.getFirstName() + " has been assigned to " + courseName);
    }

    // Method to update course information
    public void updateCourseInfo(String courseCode, String courseName, String instructorName) throws InvalidCourseDataException {
        if (courseCode == null || courseCode.isEmpty() || courseName == null || courseName.isEmpty()) {
            throw new InvalidCourseDataException("Course data is invalid.");
        }
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.instructorName = instructorName;
        System.out.println("Course information updated.");
    }

    // Method to display detailed information about the course
    public void displayCourseInfo() throws CourseNotFoundException {
        if (courseName == null || courseName.isEmpty()) {
            throw new CourseNotFoundException("Course not found.");
        }
        System.out.println("Course ID: " + courseId);
        System.out.println("Course Name: " + courseName);
        System.out.println("Course Code: " + courseCode);
        System.out.println("Instructor: " + instructorName);
    }

    // Method to retrieve a list of enrollments (students enrolled in the course)
    public List<Enrollment> GetEnrollments() {
        return enrollments;  // Returns the list of enrollments for the course
    }

    // Method to retrieve the assigned teacher for the course
    public Teacher getTeacher() {
        return assignedTeacher;
    }

    // Method to enroll a student in the course
    public void enrollStudent(Enrollment enrollment) throws IllegalArgumentException {
        if (enrollment == null) {
            throw new IllegalArgumentException("Enrollment data is missing.");
        }
        enrollments.add(enrollment);
        System.out.println("Student has been enrolled in " + courseName);
    }
}
