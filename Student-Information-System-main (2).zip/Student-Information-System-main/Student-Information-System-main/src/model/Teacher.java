package model;

import java.util.ArrayList;
import java.util.List;

public class Teacher {
    private int teacherId;               // Teacher ID
    private String firstName;            // Teacher's First Name
    private String lastName;             // Teacher's Last Name
    private String email;                // Teacher's Email

    private List<Course> assignedCourses = new ArrayList<>();  // List of courses assigned to this teacher

    // Constructor to initialize Teacher object with given attributes
    public Teacher(int teacherId, String firstName, String lastName, String email) {
        this.teacherId = teacherId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    // Getter and Setter methods for Teacher attributes
    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Method to update teacher information
    public void updateTeacherInfo(String name, String email, String expertise) {
        String[] nameParts = name.split(" ");  // Splitting the name into first and last name
        this.firstName = nameParts[0];
        this.lastName = nameParts.length > 1 ? nameParts[1] : "";
        this.email = email;
        System.out.println("Teacher information updated.");
    }

    // Method to display detailed information about the teacher
    public void displayTeacherInfo() {
        System.out.println("Teacher ID: " + teacherId);
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("Email: " + email);
    }

    // Method to retrieve a list of courses assigned to the teacher
    public List<Course> getAssignedCourses() {
        return assignedCourses;
    }

    // Method to assign a course to this teacher
    public void assignCourse(Course course) {
        assignedCourses.add(course);
        System.out.println("Course " + course.getCourseName() + " has been assigned to " + firstName + " " + lastName);
    }
}
