package model;

import java.util.Date;

public class Enrollment {
    private int enrollmentId;        // Enrollment ID
    private Student student;         // Reference to Student
    private Course course;           // Reference to Course
    private Date enrollmentDate;     // Date when the student enrolled

    // Constructor to initialize the Enrollment object
    public Enrollment(Student student, Course course, Date enrollmentDate) throws InvalidEnrollmentDataException {
        if (student == null || course == null || enrollmentDate == null) {
            throw new InvalidEnrollmentDataException("Student, Course, and Enrollment Date cannot be null.");
        }

        this.enrollmentId = enrollmentId;
        this.student = student;
        this.course = course;
        this.enrollmentDate = enrollmentDate;
    }

    public Enrollment(Student student, Course course, java.sql.Date enrollmentDate) {
    }

    public Enrollment(int student, int course, java.sql.Date date) {
    }


    // Getter for Enrollment ID
    public int getEnrollmentId() {
        return enrollmentId;
    }

    // Setter for Enrollment ID
    public void setEnrollmentId(int enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    // Getter for Student
    public Student getStudent() {
        return student;
    }

    // Setter for Student
    public void setStudent(Student student) throws InvalidEnrollmentDataException {
        if (student == null) {
            throw new InvalidEnrollmentDataException("Student cannot be null.");
        }
        this.student = student;
    }

    // Getter for Course
    public Course getCourse() {
        return course;
    }

    // Setter for Course
    public void setCourse(Course course) throws InvalidEnrollmentDataException {
        if (course == null) {
            throw new InvalidEnrollmentDataException("Course cannot be null.");
        }
        this.course = course;
    }

    // Getter for Enrollment Date
    public java.sql.Date getEnrollmentDate() {
        return (java.sql.Date) enrollmentDate;
    }

    // Setter for Enrollment Date
    public void setEnrollmentDate(Date enrollmentDate) throws InvalidEnrollmentDataException {
        if (enrollmentDate == null) {
            throw new InvalidEnrollmentDataException("Enrollment Date cannot be null.");
        }
        this.enrollmentDate = enrollmentDate;
    }

    // Method to display Enrollment Information
    public void displayEnrollmentInfo() {
        System.out.println("Enrollment ID: " + enrollmentId);
        System.out.println("Student: " + student.getFirstName() + " " + student.getLastName() + " (ID: " + student.getStudentId() + ")");
        System.out.println("Course: " + course.getCourseName() + " (ID: " + course.getCourseId() + ")");
        System.out.println("Enrollment Date: " + enrollmentDate);
    }

    // Get the associated student (Method to retrieve student associated with enrollment)
    public Student GetStudent() {
        return student;
    }

    // Get the associated course (Method to retrieve course associated with enrollment)
    public Course GetCourse() {
        return course;
    }
}
