package Test;

import model.*;
// Import the exception class from the 'exception' package (if that's where the class is defined)
import exception.PaymentValidationException;

import model.DuplicateEnrollmentException;
import model.InvalidCourseDataException;
import model.InvalidEnrollmentDataException;
import model.TeacherNotFoundException;

import java.util.Date;

public class SISDriver {

    public static void main(String[] args) throws TeacherNotFoundException, model.PaymentValidationException, PaymentValidationException {
        // Create an instance of the SIS system
        SIS sis = new SIS();

        // Create some test students, teachers, and courses
        Student student1 = new Student(1, "John", "Doe", new Date(), "johndoe@example.com", "123 Main St");
        Student student2 = new Student(2, "Jane", "Smith", new Date(), "janesmith@example.com", "456 Elm St");

        Teacher teacher1 = new Teacher(1, "Dr. Alice", "Johnson", "alice.johnson@school.com");
        Teacher teacher2 = new Teacher(2, "Dr. Bob", "Williams", "bob.williams@school.com");

        Course course1 = null;
        try {
            course1 = new Course(101, "Math 101");
        } catch (model.InvalidCourseDataException e) {
            throw new RuntimeException(e);
        }
        Course course2 = null;
        try {
            course2 = new Course(102, "History 101");
        } catch (InvalidCourseDataException e) {
            throw new RuntimeException(e);
        }

        // Add students to SIS
        sis.getStudents().add(student1);
        sis.getStudents().add(student2);

        // Add teachers to SIS
        sis.getTeachers().add(teacher1);
        sis.getTeachers().add(teacher2);

        // Add courses to SIS
        sis.getCourses().add(course1);
        sis.getCourses().add(course2);

        // Assign courses to teachers
        sis.AssignTeacherToCourse(teacher1, course1);
        sis.AssignTeacherToCourse(teacher2, course2);

        // Enroll students in courses
        try {
            sis.EnrollStudentInCourse(student1, course1);
            sis.EnrollStudentInCourse(student2, course2);
        } catch (DuplicateEnrollmentException | InvalidEnrollmentDataException e) {
            System.out.println("Error enrolling student in course: " + e.getMessage());
        }

        // Add payments
        sis.RecordPayment(student1, 500, new Date());
        sis.RecordPayment(student2, 600, new Date());

        // Retrieve and display enrollments for a student
        sis.GenerateEnrollmentReport(course1);  // Print all enrollments for course1

        // Retrieve and display courses assigned to a teacher
        sis.GenerateEnrollmentReport(course2);  // Print all enrollments for course2

        // Generate and display payment report for a student
        sis.GeneratePaymentReport(student1);  // Print payments for student1
    }
}
