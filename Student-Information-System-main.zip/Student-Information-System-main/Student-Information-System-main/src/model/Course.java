package model;

import exception.CourseNotFoundException;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private int courseId;
    private String courseName;
    private String courseCode;
    private String instructorName;
    private Teacher assignedTeacher;
    private List<Enrollment> enrollments = new ArrayList<>();

    public Course(int courseId, String courseName) throws InvalidCourseDataException {
        if (courseId <= 0 || courseName == null || courseName.isEmpty()) {
            throw new InvalidCourseDataException("Invalid data provided for the course.");
        }
        this.courseId = courseId;
        this.courseName = courseName;
    }

    // Getters and Setters
    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    public void assignTeacher(Teacher teacher) throws TeacherNotFoundException {
        if (teacher == null) {
            throw new TeacherNotFoundException("Teacher not found for this course.");
        }
        this.assignedTeacher = teacher;
        System.out.println(teacher.getFirstName() + " has been assigned to " + courseName);
    }

    public void updateCourseInfo(String courseCode, String courseName, String instructorName) throws InvalidCourseDataException {
        if (courseCode == null || courseCode.isEmpty() || courseName == null || courseName.isEmpty()) {
            throw new InvalidCourseDataException("Course data is invalid.");
        }
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.instructorName = instructorName;
        System.out.println("Course information updated.");
    }

    public void displayCourseInfo() throws CourseNotFoundException {
        if (courseName == null || courseName.isEmpty()) {
            throw new CourseNotFoundException("Course not found.");
        }
        System.out.println("Course ID: " + courseId);
        System.out.println("Course Name: " + courseName);
        System.out.println("Course Code: " + courseCode);
        System.out.println("Instructor: " + instructorName);
    }

    public List<Enrollment> getEnrollments() {
        return enrollments;
    }

    public Teacher getTeacher() {
        return assignedTeacher;
    }

    public void enrollStudent(Enrollment enrollment) throws IllegalArgumentException {
        if (enrollment == null) {
            throw new IllegalArgumentException("Enrollment data is missing.");
        }
        enrollments.add(enrollment);
        System.out.println("Student has been enrolled in " + courseName);
    }
}