package model;

import java.sql.Date;

public class Enrollment {
    private int enrollmentId;
    private Student student;
    private Course course;
    private Date enrollmentDate;

    public Enrollment(Student student, Course course, Date enrollmentDate) throws InvalidEnrollmentDataException {
        if (student == null || course == null || enrollmentDate == null) {
            throw new InvalidEnrollmentDataException("Student, Course, and Enrollment Date cannot be null.");
        }
        this.student = student;
        this.course = course;
        this.enrollmentDate = enrollmentDate;
    }

    public int getEnrollmentId() {
        return enrollmentId;
    }

    public void setEnrollmentId(int enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) throws InvalidEnrollmentDataException {
        if (student == null) {
            throw new InvalidEnrollmentDataException("Student cannot be null.");
        }
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) throws InvalidEnrollmentDataException {
        if (course == null) {
            throw new InvalidEnrollmentDataException("Course cannot be null.");
        }
        this.course = course;
    }

    public Date getEnrollmentDate() {
        return enrollmentDate;
    }

    public void setEnrollmentDate(Date enrollmentDate) throws InvalidEnrollmentDataException {
        if (enrollmentDate == null) {
            throw new InvalidEnrollmentDataException("Enrollment Date cannot be null.");
        }
        this.enrollmentDate = enrollmentDate;
    }

    public void displayEnrollmentInfo() {
        System.out.println("Enrollment ID: " + enrollmentId);
        System.out.println("Student: " + student.getFirstName() + " " + student.getLastName() + " (ID: " + student.getStudentId() + ")");
        System.out.println("Course: " + course.getCourseName() + " (ID: " + course.getCourseId() + ")");
        System.out.println("Enrollment Date: " + enrollmentDate);
    }
}