package model;

// Custom Exception Definitions
public class PaymentValidationException extends Exception {
    public PaymentValidationException(String message) {
        super(message);
    }
}
